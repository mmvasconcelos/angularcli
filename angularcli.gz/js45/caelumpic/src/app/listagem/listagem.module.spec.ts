import { ListagemModule } from './listagem.module';

describe('ListagemModule', () => {
  let listagemModule: ListagemModule;

  beforeEach(() => {
    listagemModule = new ListagemModule();
  });

  it('should create an instance', () => {
    expect(listagemModule).toBeTruthy();
  });
});
