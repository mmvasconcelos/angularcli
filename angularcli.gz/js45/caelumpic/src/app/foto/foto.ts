export class Foto{
url:string = '';
titulo: string = '';
descricao: string = '';
_id: string;
}