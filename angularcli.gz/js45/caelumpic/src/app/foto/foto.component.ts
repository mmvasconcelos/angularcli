import { Component, Input, ViewEncapsulation } from '@angular/core';
import { Foto } from './foto';

@Component({
  selector: 'foto',
  templateUrl: './foto.component.html',
  styleUrls: ['./foto.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class FotoComponent{
  //@Input() titulo;
  //@Input() url;

  @Input() foto: Foto;
}
