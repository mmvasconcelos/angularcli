import { Component } from '@angular/core';
import { FotoService } from '../servicos/foto.service';
import { Foto } from '../foto/foto';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'cadastro',
  templateUrl: './cadastro.component.html',
})
export class CadastroComponent {

  foto = new Foto();
  formCadastro: FormGroup

  constructor(private servico: FotoService
    , private rota: ActivatedRoute
    , private roteador: Router
    , private formBuilder: FormBuilder) {

        this.formCadastro = formBuilder.group({
        titulo: ['', Validators.compose(
          [
            Validators.required,
            Validators.minLength(3)
          ]
        )],
        url: [Validators.required],
        descricao: ''
      });

    this.rota.params
      .subscribe(
        parametros => {
          if (parametros.idFoto) {
            this.servico
            .obterFoto(parametros.idFoto)
            .subscribe(fotoDaApi => this.foto = fotoDaApi);
           }
        }
      );
  }
  salvar() {
    if (this.foto._id){
    this.servico
      .alterar(this.foto)
      .subscribe(
        () => {
          console.log(`Foto ${this.foto.titulo} alterada com sucesso`);

          setTimeout(
            () => this.roteador.navigate([''])
            , 1000
          );
          }
          , erro => console.log(erro)
      );
    } else {
      this.servico
      .cadastrar(this.foto)
      .subscribe(
        () => {
          console.log(`Foto ${this.foto.titulo} salva com sucesso`);
          this.foto = new Foto();
        }
        , erro => console.log(erro)
      );
    }
  }
}

